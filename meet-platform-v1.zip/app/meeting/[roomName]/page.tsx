import MeetingRoom from "@/components/MeetingRoom";

export default async function MeetingPage({ params }: { params: Promise<{ roomName: string }> }) {
  const { roomName } = await params;
  return <MeetingRoom roomName={decodeURIComponent(roomName)} />;
}
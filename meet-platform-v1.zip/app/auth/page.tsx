"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signInWithEmailAndPassword
} from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function AuthPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"login"|"signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => onAuthStateChanged(auth, user => {
    if (user) router.replace("/dashboard");
  }), [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      if (mode === "login") await signInWithEmailAndPassword(auth, email, password);
      else await createUserWithEmailAndPassword(auth, email, password);
      router.replace("/dashboard");
    } catch (err: any) {
      setError(err?.message || "Authentication failed.");
    }
  }

  return (
    <main className="container">
      <div className="card" style={{maxWidth:520, margin:"70px auto"}}>
        <h1>{mode === "login" ? "Welcome back" : "Create your account"}</h1>
        <form onSubmit={submit} className="grid" style={{marginTop:20}}>
          <input className="input" type="email" required placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" type="password" required minLength={6} placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
          <button className="btn" type="submit">{mode === "login" ? "Sign in" : "Sign up"}</button>
        </form>
        {error && <p className="error">{error}</p>}
        <button className="btn secondary" style={{marginTop:12}} onClick={()=>setMode(mode==="login"?"signup":"login")}>
          {mode === "login" ? "Create account" : "I already have an account"}
        </button>
      </div>
    </main>
  );
}
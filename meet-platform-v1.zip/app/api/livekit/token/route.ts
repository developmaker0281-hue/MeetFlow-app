import { NextRequest, NextResponse } from "next/server";
import { AccessToken } from "livekit-server-sdk";
import { adminAuth } from "@/lib/firebase-admin";

export async function POST(request: NextRequest) {
  try {
    const authorization = request.headers.get("authorization");
    if (!authorization?.startsWith("Bearer ")) {
      return NextResponse.json({error:"Unauthorized"}, {status:401});
    }

    const firebaseToken = authorization.slice("Bearer ".length);
    const decoded = await adminAuth.verifyIdToken(firebaseToken);

    const body = await request.json();
    const roomName = String(body.roomName || "").trim();
    if (!roomName) return NextResponse.json({error:"roomName is required"}, {status:400});

    const identity = decoded.uid;
    const name = String(body.participantName || decoded.email || "Participant");

    const token = new AccessToken(
      process.env.LIVEKIT_API_KEY!,
      process.env.LIVEKIT_API_SECRET!,
      { identity, name }
    );

    token.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true
    });

    const jwt = await token.toJwt();

    return NextResponse.json({
      serverUrl: process.env.NEXT_PUBLIC_LIVEKIT_URL,
      participantToken: jwt
    }, {status:201});
  } catch (error) {
    console.error(error);
    return NextResponse.json({error:"Token generation failed"}, {status:500});
  }
}
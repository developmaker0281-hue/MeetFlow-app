import Link from "next/link";

export default function Home() {
  return (
    <main className="container">
      <div className="card" style={{marginTop: 70}}>
        <p className="muted">Meet V1</p>
        <h1 className="title">Simple, real-time online meetings.</h1>
        <p className="muted">
          Video, audio, screen sharing, participant controls and chat-ready architecture.
        </p>
        <div className="row" style={{marginTop: 22}}>
          <Link className="btn" href="/auth">Sign in / Create account</Link>
          <Link className="btn secondary" href="/dashboard">Open dashboard</Link>
        </div>
      </div>
    </main>
  );
}
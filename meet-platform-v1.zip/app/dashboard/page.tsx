"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth, db } from "@/lib/firebase";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";

export default function Dashboard() {
  const router = useRouter();
  const [uid, setUid] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [meetingId, setMeetingId] = useState("");

  useEffect(() => onAuthStateChanged(auth, u => {
    if (!u) router.replace("/auth");
    else setUid(u.uid);
  }), [router]);

  async function createMeeting() {
    if (!uid) return;
    setBusy(true);
    try {
      const ref = await addDoc(collection(db, "meetings"), {
        ownerId: uid,
        title: "Instant meeting",
        createdAt: serverTimestamp(),
        status: "scheduled"
      });
      router.push(`/meeting/${ref.id}`);
    } finally {
      setBusy(false);
    }
  }

  function join() {
    const id = meetingId.trim();
    if (id) router.push(`/meeting/${encodeURIComponent(id)}`);
  }

  return (
    <main className="container">
      <div className="row spread">
        <div>
          <p className="muted">Dashboard</p>
          <h1>Meet</h1>
        </div>
        <button className="btn secondary" onClick={()=>signOut(auth)}>Sign out</button>
      </div>

      <div className="grid grid2" style={{marginTop:24}}>
        <div className="card">
          <h2>Start an instant meeting</h2>
          <p className="muted">Create a room and share its link with participants.</p>
          <button className="btn" disabled={busy} onClick={createMeeting}>
            {busy ? "Creating…" : "New meeting"}
          </button>
        </div>

        <div className="card">
          <h2>Join a meeting</h2>
          <p className="muted">Paste a meeting ID.</p>
          <input className="input" value={meetingId} onChange={e=>setMeetingId(e.target.value)} placeholder="Meeting ID" />
          <button className="btn" style={{marginTop:12}} onClick={join}>Join</button>
        </div>
      </div>
    </main>
  );
}
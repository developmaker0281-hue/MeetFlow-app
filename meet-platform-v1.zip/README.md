# Meet Platform V1

A deployable V1 online meeting application built with Next.js, Firebase Authentication/Firestore/Storage, and LiveKit.

## Included

- Firebase email/password authentication
- Dashboard
- Create instant meeting
- Join by meeting ID
- Live video/audio rooms
- Screen sharing through LiveKit's VideoConference UI
- Participant management UI supplied by LiveKit
- Meeting chat UI supplied by LiveKit
- Secure server-side LiveKit token endpoint
- Firestore security rules
- Firebase Storage rules
- Responsive dark UI

## 1. Install

```bash
npm install
npm run dev
```

## 2. Firebase

Create a Firebase project and register a Web app.

Enable:
- Authentication -> Email/Password
- Firestore Database
- Storage

Copy the Firebase web config into `.env.local`.

For the server token endpoint, create a Firebase Admin service account and set:
- FIREBASE_PROJECT_ID
- FIREBASE_CLIENT_EMAIL
- FIREBASE_PRIVATE_KEY

Deploy `firestore.rules` and `storage.rules`.

## 3. LiveKit

Create a LiveKit Cloud project and copy:
- API key
- API secret
- WebSocket URL

Put them in `.env.local`.

Never expose `LIVEKIT_API_SECRET` to the browser.

## 4. Run

```bash
npm run dev
```

Open http://localhost:3000.

## 5. Production

Use a production HTTPS deployment. LiveKit's production token endpoint must remain server-side and authenticated. Firebase/Next.js can be deployed using Firebase's supported Next.js hosting/App Hosting path or another Next.js host.

## V1 next upgrades

- Google sign-in
- meeting scheduling and calendar
- invite links
- waiting room
- host/co-host roles stored in Firestore
- persistent chat history
- recording pipeline
- transcription
- polls
- breakout rooms
- organization/workspace support
- admin dashboard
- push/email notifications

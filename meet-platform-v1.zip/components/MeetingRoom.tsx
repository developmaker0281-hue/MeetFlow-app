"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  LiveKitRoom,
  VideoConference,
  RoomAudioRenderer
} from "@livekit/components-react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "@/lib/firebase";

export default function MeetingRoom({ roomName }: { roomName: string }) {
  const router = useRouter();
  const [token, setToken] = useState<string>();
  const [serverUrl, setServerUrl] = useState<string>();
  const [error, setError] = useState("");

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async user => {
      if (!user) {
        router.replace("/auth");
        return;
      }
      try {
        const idToken = await user.getIdToken();
        const res = await fetch("/api/livekit/token", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${idToken}` },
          body: JSON.stringify({
            roomName,
            participantName: user.email || "Guest",
            participantIdentity: user.uid
          })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Could not create meeting token.");
        setToken(data.participantToken);
        setServerUrl(data.serverUrl);
      } catch (e: any) {
        setError(e.message || "Could not join meeting.");
      }
    });
    return () => unsub();
  }, [roomName, router]);

  if (error) return <main className="container"><div className="card"><h2>Unable to join</h2><p className="error">{error}</p><button className="btn" onClick={()=>router.push("/dashboard")}>Back</button></div></main>;
  if (!token || !serverUrl) return <main className="container"><div className="card"><h2>Joining meeting…</h2><p className="muted">Room: {roomName}</p></div></main>;

  return (
    <div className="meeting-shell">
      <LiveKitRoom
        token={token}
        serverUrl={serverUrl}
        connect
        audio
        video
        data-lk-theme="default"
        style={{height:"100vh"}}
        onDisconnected={()=>router.push("/dashboard")}
      >
        <div className="meeting-stage">
          <VideoConference />
        </div>
        <RoomAudioRenderer />
      </LiveKitRoom>
    </div>
  );
}